import { motion } from 'framer-motion';
import { Flame } from 'lucide-react';
import html2canvas from 'html2canvas';
import { useRef } from 'react';

const shabads = [
  { 
    text: "Gun gobind gaiyo nahi, janam akarth keen.\nKahu nanak bhaj har mana, jih bidh jal kau meen.", 
    mean: "You have not sung the Lord's praises; your life is wasted. Worship the Lord, just as the fish loves the water." 
  },
  { 
    text: "Jo upjio so binas hai, paro aaj ke kaal.\nNanak har gun gai le, chaad sagal janjal.", 
    mean: "Whatever is created shall be destroyed. O Nanak, sing the Glorious Praises of the Lord." 
  },
  { 
    text: "Bal chutkyo bandhan pare, kachu na hot upaaye.\nKahu nanak ab ot har, gaj jio hohu sahaaye.", 
    mean: "Strength is gone, bonds are shackles. Says Nanak, the Lord is now my Support." 
  },
  { 
    text: "Chinta ta ki kijiye, jo anhoni hoye.\nIh marag sansar ko, nanak thir nahi koye.", 
    mean: "Worry only about what is not destined to happen. In this world, nothing is permanent." 
  }
];

export default function PosterGenerator({ userName, shabad, onDownload }) {
  const posterRef = useRef(null);

  const handleDownload = async () => {
    if (posterRef.current) {
      const canvas = await html2canvas(posterRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: null,
      });
      
      const link = document.createElement('a');
      link.download = `nadar-blessing-${userName.replace(/\s+/g, '-').toLowerCase()}.jpg`;
      link.href = canvas.toDataURL('image/jpeg', 0.95);
      link.click();
      
      if (onDownload) onDownload();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="w-full max-w-2xl mx-auto"
    >
      <div
        ref={posterRef}
        className="relative w-full aspect-[3/4] rounded-lg overflow-hidden shadow-2xl shadow-gold/20"
      >
        <img
          src="https://images.unsplash.com/photo-1587408703843-79c646522665?q=80&w=1920&auto=format&fit=crop"
          alt="Background"
          className="absolute inset-0 w-full h-full object-cover"
          crossOrigin="anonymous"
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>
        
        <div className="absolute inset-0 border-4 border-gold/30 m-4">
          <div className="absolute inset-0 border-2 border-gold/50 m-2"></div>
        </div>
        
        <div className="relative h-full flex flex-col items-center justify-between p-8 text-center">
          <div className="flex flex-col items-center mt-8">
            <Flame className="w-16 h-16 text-gold mb-4" strokeWidth={1.5} />
            
            <h1 
              className="font-cinzel font-black text-gold break-words w-full px-4"
              style={{
                fontSize: userName.length > 20 ? '2rem' : userName.length > 15 ? '2.5rem' : '3rem',
                textShadow: '0 0 20px rgba(212, 175, 55, 0.5), 0 0 40px rgba(212, 175, 55, 0.3)',
                lineHeight: '1.2',
              }}
            >
              {userName}
            </h1>
            
            <p className="text-gray-300 tracking-widest text-sm mt-2 uppercase">
              Received the 9th Light
            </p>
          </div>
          
          <div className="flex-1 flex items-center justify-center px-6">
            <div className="max-w-xl">
              <p 
                className="font-playfair text-white text-lg leading-relaxed mb-4"
                style={{ 
                  textShadow: '0 2px 4px rgba(0,0,0,0.8)',
                  whiteSpace: 'pre-line'
                }}
              >
                {shabad.text}
              </p>
              <p className="text-gray-400 text-sm italic font-playfair leading-relaxed">
                {shabad.mean}
              </p>
            </div>
          </div>
          
          <div className="space-y-2">
            <p className="text-gold text-sm tracking-wider">
              350th Martyrdom Year
            </p>
            <p className="text-gray-400 text-xs">
              Sis Ganj Sahib • Anandpur Sahib
            </p>
            <p className="text-gray-600 text-xs mt-4">
              Dev: Karan (Chitkara Univ)
            </p>
          </div>
        </div>
      </div>
      
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={handleDownload}
        className="mt-6 w-full py-4 bg-gradient-to-r from-gold/20 to-gold/10 backdrop-blur-md border border-gold/30 rounded-lg text-gold font-bold tracking-wider hover:border-gold/50 transition-all duration-300 shadow-lg shadow-gold/10"
      >
        📥 Download HD Poster
      </motion.button>
    </motion.div>
  );
}

export { shabads };
