import { motion } from 'framer-motion';

export default function Diya() {
  return (
    <div className="flex flex-col items-center justify-center mb-8">
      <div className="relative">
        <div className="w-20 h-24 bg-gradient-to-b from-amber-700 to-amber-900 rounded-b-full relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-3 bg-amber-800 rounded-t-full"></div>
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-16 h-2 bg-amber-900"></div>
        </div>
        
        <motion.div
          className="absolute -top-8 left-1/2 -translate-x-1/2"
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.9, 1, 0.9],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="relative w-6 h-12">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-12 bg-gradient-to-t from-orange-600 via-yellow-500 to-yellow-300 rounded-full blur-sm"></div>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-10 bg-gradient-to-t from-orange-500 via-yellow-400 to-yellow-200 rounded-full"></div>
            <motion.div
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-2 h-8 bg-gradient-to-t from-yellow-400 to-white rounded-full"
              animate={{
                height: ["32px", "36px", "32px"],
                x: ["-50%", "-48%", "-50%"],
              }}
              transition={{
                duration: 0.8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </div>
        </motion.div>
        
        <motion.div
          className="absolute -top-8 left-1/2 -translate-x-1/2 w-24 h-24 rounded-full bg-orange-500/30 blur-2xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>
    </div>
  );
}
