import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Diya from './components/Diya';
import ParticleBackground from './components/ParticleBackground';
import PosterGenerator, { shabads } from './components/PosterGenerator';

function App() {
  const [userName, setUserName] = useState('');
  const [showPoster, setShowPoster] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedShabad, setSelectedShabad] = useState(null);

  const handleReveal = () => {
    if (!userName.trim()) return;
    
    setLoading(true);
    const randomShabad = shabads[Math.floor(Math.random() * shabads.length)];
    setSelectedShabad(randomShabad);
    
    setTimeout(() => {
      setLoading(false);
      setShowPoster(true);
    }, 2000);
  };

  const handleReset = () => {
    setShowPoster(false);
    setUserName('');
    setSelectedShabad(null);
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white overflow-hidden">
      <ParticleBackground />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <AnimatePresence mode="wait">
            {!showPoster ? (
              <motion.div
                key="input"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.6 }}
                className="text-center"
              >
                <Diya />
                
                <motion.h1 
                  className="font-cinzel text-5xl md:text-7xl font-black text-gold mb-4"
                  style={{ textShadow: '0 0 30px rgba(212, 175, 55, 0.5)' }}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  Nadar: The 9th Light
                </motion.h1>
                
                <motion.p 
                  className="text-gray-400 text-lg mb-12 tracking-wide"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  Commemorating 350 Years of Guru Tegh Bahadur Ji's Martyrdom
                </motion.p>
                
                <motion.div
                  className="max-w-md mx-auto space-y-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <div className="backdrop-blur-md bg-white/5 border border-gold/20 rounded-lg p-8 shadow-2xl shadow-gold/10">
                    <label className="block text-gold text-sm tracking-widest mb-3 uppercase">
                      Your Name
                    </label>
                    <input
                      type="text"
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleReveal()}
                      placeholder="Enter your full name"
                      className="w-full px-4 py-3 bg-black/50 border border-gold/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-gold/60 transition-all duration-300"
                      disabled={loading}
                    />
                  </div>
                  
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleReveal}
                    disabled={!userName.trim() || loading}
                    className="w-full py-4 bg-gradient-to-r from-gold/30 to-gold/20 backdrop-blur-md border border-gold/40 rounded-lg font-bold text-gold tracking-wider hover:border-gold/60 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shadow-lg shadow-gold/20"
                  >
                    {loading ? (
                      <span className="flex items-center justify-center">
                        <motion.span
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          className="inline-block mr-2"
                        >
                          ⚪
                        </motion.span>
                        Connecting to History...
                      </span>
                    ) : (
                      '🌹 Reveal My Blessing 🌹'
                    )}
                  </motion.button>
                  
                  <p className="text-gray-600 text-xs text-center mt-6">
                    Each blessing is a sacred teaching from Sri Guru Granth Sahib Ji
                  </p>
                </motion.div>
              </motion.div>
            ) : (
              <motion.div
                key="poster"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-6"
              >
                <PosterGenerator 
                  userName={userName} 
                  shabad={selectedShabad}
                  onDownload={() => {}}
                />
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleReset}
                  className="w-full max-w-2xl mx-auto block py-3 bg-white/5 backdrop-blur-md border border-white/20 rounded-lg text-gray-400 hover:text-white hover:border-white/40 transition-all duration-300"
                >
                  ← Create Another Blessing
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

export default App;
